function search(){
	url_gs = $('h3 a').attr("href");
console.log(url_gs);
}
setInterval (search, 1000);